// 
// N-Tier database app: Data Acces Tier 
// 
// Daniel A. Noventa 
// U. of Illinois, Chicago 
// CS341, Fall 2013 
// Homework 8 
//

using System;

namespace databases
{
	public class DataAccess
	{
		public DataAccess ()
		{

		

	

				                   

		}
	}
}

